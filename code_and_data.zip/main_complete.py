import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import pandas as pd
import numpy as np
import sklearn
import matplotlib.pyplot as plt
from spacy_langdetect import LanguageDetector
from spacy.language import Language
import spacy
import nltk
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE
from sklearn.dummy import DummyRegressor
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neural_network import MLPRegressor
import time

plt.rc('font', size=18); plt.rcParams['figure.constrained_layout.use'] = True

#read csvs and show shape
listing_df = pd.read_csv("listings.csv")
reviews_df = pd.read_csv("reviews.csv")
print(listing_df.head())
print("-----------")
print(reviews_df.head())
print("-----------")

#drop useless columns and missing values
listing_df = listing_df.drop(columns=['listing_url', 'scrape_id', 'last_scraped',
                                      'source', 'name', 'picture_url',
                                      'host_id', 'host_url', 'host_name',
                                      'host_since', 'host_thumbnail_url',
                                      'host_picture_url', 'host_neighbourhood',
                                      'host_listings_count', 'neighbourhood',
                                      'neighbourhood_group_cleansed', 'latitude',
                                      'longitude', 'property_type',
                                      'bathrooms', 'bedrooms', 'beds',
                                      'minimum_nights', 'maximum_nights',
                                      'minimum_minimum_nights', 'maximum_minimum_nights',
                                      'minimum_maximum_nights', 'maximum_maximum_nights',
                                      'calendar_updated', 'has_availability',
                                      'availability_30', 'availability_60',
                                      'availability_90', 'availability_365',
                                      'calendar_last_scraped', 'number_of_reviews_l30d',
                                      'first_review', 'last_review',
                                      'license', 'calculated_host_listings_count',
                                      'calculated_host_listings_count_entire_homes',
                                      'calculated_host_listings_count_private_rooms',
                                      'calculated_host_listings_count_shared_rooms'])
reviews_df = reviews_df.drop(columns=['id', 'date', 'reviewer_id', 'reviewer_name'])
print('Dimensions before dropping the rows with missing values:')
print(listing_df.shape)
print("-----------")
print(reviews_df.shape)
print("-----------")
print('Dimensions after dropping the REVIEWS with missing values:')
reviews_df.dropna(inplace=True)
reviews_df.reset_index(drop=True, inplace=True)
print(reviews_df.shape)
print("-----------")

#cleaning listings
listing_df['description'] = listing_df['description'].apply(str)
listing_df['description'] = listing_df['description'].apply(len)
listing_df['neighborhood_overview'] = listing_df['neighborhood_overview'].apply(str)
listing_df['neighborhood_overview'] = listing_df['neighborhood_overview'].apply(len)

def binarize(key, column):
    column = column.apply(str)
    for i in range(len(column)):
        if key in column[i]:
            column[i] = 1
        else:
            column[i] = 0
    return column
listing_df['host_location'] = binarize('Dublin', listing_df['host_location'])

listing_df['host_about'] = listing_df['host_about'].apply(str)
listing_df['host_about'] = listing_df['host_about'].apply(len)

for i in range(len(listing_df['host_response_time'])):
    if listing_df['host_response_time'][i] == 'within an hour':
        listing_df['host_response_time'].at[i] = 1
    elif listing_df['host_response_time'][i] == 'within a few hours':
        listing_df['host_response_time'].at[i] = 5
    elif listing_df['host_response_time'][i] == 'within a day':
        listing_df['host_response_time'].at[i] = 20
    elif listing_df['host_response_time'][i] == 'a few days or more':
        listing_df['host_response_time'].at[i] = 50
    else: listing_df['host_response_time'].at[i] = 10000

listing_df['host_response_rate'] = \
    listing_df['host_response_rate'].str.rstrip('%').astype('float') / 100.0
listing_df['host_acceptance_rate'] = \
    listing_df['host_acceptance_rate'].str.rstrip('%').astype('float') / 100.0

listing_df['host_is_superhost'] = binarize('t', listing_df['host_is_superhost'])

listing_df['gives_email'] = 0
listing_df['gives_phone'] = 0
listing_df['gives_work_email'] = 0
for i in range(len(listing_df['host_verifications'])):
    if "'email'" in listing_df['host_verifications'][i]: listing_df['gives_email'].at[i] = 1
    if "'phone'" in listing_df['host_verifications'][i]: listing_df['gives_phone'].at[i] = 1
    if "'work_email'" in listing_df['host_verifications'][i]: listing_df['gives_work_email'].at[i] = 1
listing_df.drop(columns=['host_verifications'], inplace=True)

listing_df['host_has_profile_pic'] = binarize('t', listing_df['host_has_profile_pic'])

listing_df['host_identity_verified'] = binarize('t', listing_df['host_identity_verified'])

listing_df['neighbourhood_cleansed'] = binarize('Dublin', listing_df['neighbourhood_cleansed'])

listing_df['is_entire_place'] = 0
listing_df['is_shared'] = 0
for i in range(len(listing_df['room_type'])):
    if 'entire' in listing_df['room_type'][i]: listing_df['room_type'].at[i] = 1
    if 'shared' in listing_df['room_type'][i]: listing_df['room_type'].at[i] = 1
listing_df.drop(columns=['room_type'], inplace=True)

listing_df['bathrooms_text'] = listing_df['bathrooms_text'].apply(str)
listing_df['is_bathroom_shared'] = 0
listing_df['bathrooms_count'] = 0
for i in range(len(listing_df['bathrooms_text'])):
    if 'hared' in listing_df['bathrooms_text'][i]: listing_df['is_bathroom_shared'].at[i] = 1
    if 'alf' in listing_df['bathrooms_text'][i]: listing_df['bathrooms_count'].at[i] = 0.5
    else:
        listing_df['bathrooms_count'].at[i] = float(listing_df['bathrooms_text'].at[i].split(" ")[0])
listing_df.drop(columns=['bathrooms_text'], inplace=True)

listing_df['amenities'] = listing_df['amenities'].str.split(',').apply(len)

listing_df['price'] = listing_df['price'].str.lstrip('$')
listing_df.rename(columns={'price': 'property_price'}, inplace=True)

listing_df['instant_bookable'] = binarize('t', listing_df['instant_bookable'])

listing_df = listing_df.iloc[:, [0,20,21,22,23,24,25,26,1,2,3,4,5,6,7,8,9,10,
                                 11,12,13,14,15,16,17,18,19,27,28,29,30,
                                 31,32,33,34,35]]
"""
#remove non-english reviews

def get_lang_detector(nlp, name):
    return LanguageDetector()

nlp = spacy.load('en_core_web_sm')
Language.factory("language_detector", func=get_lang_detector)
nlp.add_pipe('language_detector', last=True)
for i in range(len(reviews_df)):
    print(i)
    doc = nlp(reviews_df.at[i, 'comments'])
    detect = doc._.language
    if (detect['language'] != 'en'):
        reviews_df = reviews_df.drop(i, inplace=False, axis=0)
reviews_df.reset_index(drop=True, inplace=True)
reviews_df.to_csv('english_reviews.csv', index=False)

#tokenize reviews; previous section can be commented if previously executed
reviews_df = pd.read_csv('english_reviews.csv')
comments = reviews_df.iloc[:,1].to_numpy().tolist()
for i in range(len(comments)):
    print(i)
    comments[i] = word_tokenize(comments[i])
    #comments[i] = [PorterStemmer().stem(token) for token in comments[i]]
    comments[i] = [WordNetLemmatizer().lemmatize(token) for token in comments[i] if token not in set(
        nltk.corpus.stopwords.words('english'))]
    comments[i] = ' '.join(str(t) for t in comments[i])
reviews_df = reviews_df.drop(columns=['comments'])
reviews_df['comments'] = comments
reviews_df.to_csv('clean_reviews.csv', index=False)
"""
#TF-IDF, pruning (min/max_df cross-validation)
colours = ['red', 'green', 'blue']
fig, (ax1, ax2) = plt.subplots(1,2)
reviews_df = pd.read_csv('clean_reviews.csv')
max_df_range = [0.25, 0.4, 0.99]
min_df_range = [0.01, 0.1, 0.2]
for index, max_df in enumerate(max_df_range):
    mean_MSE = []
    mean_MAE = []
    std_MSE = []
    std_MAE = []
    for min_df in min_df_range:
        print("min: " + str(min_df) + " max: " + str(max_df))
        x=reviews_df['comments']
        vectorizer = TfidfVectorizer(stop_words=nltk.corpus.stopwords.words('english'),
                                     max_df=max_df, min_df=min_df)
        X = vectorizer.fit_transform(x.values.astype(str))
        tfidf_df = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
        appended_df = pd.concat([reviews_df, tfidf_df], axis=1)
        appended_df.drop(columns=['comments'], inplace=True)
        appended_df = appended_df.groupby(appended_df['listing_id'], as_index=False).mean()
        feature_df = pd.merge(listing_df, appended_df.rename(columns={'listing_id':'id'}),
                              on='id', how='left')
        feature_df = feature_df.fillna(0)
        feature_df = feature_df.replace('nan', 0)
        feature_df['property_price'].replace(',', '', regex=True, inplace=True)
        X = feature_df.iloc[:, 8:].to_numpy()
        #using only rating and standard linear regression for cross-validation
        y = feature_df.iloc[:, 1]
        model = LinearRegression()
        temp_MSE = []
        temp_MAE = []
        for train, test in KFold(n_splits=5).split(X):
            model.fit(X[train], y[train])
            ypred = model.predict(X[test])
            temp_MSE.append(MSE(y[test], ypred))
            temp_MAE.append(MAE(y[test], ypred))
            #print(np.column_stack((ypred, y[test])))
            print(model.coef_)
            print(feature_df.iloc[:, 8:].columns)
        mean_MSE.append(np.array(temp_MSE).mean())
        std_MSE.append(np.array(temp_MSE).std())
        mean_MAE.append(np.array(temp_MAE).mean())
        std_MAE.append(np.array(temp_MAE).std())
    ax1.errorbar(min_df_range, mean_MSE, yerr=std_MSE, linewidth=2,
                 color=colours[index], label=max_df)
    ax2.errorbar(min_df_range, mean_MAE, yerr=std_MAE, linewidth=2,
                 color=colours[index], label=max_df)
ax1.legend(loc = "upper right", title="max_df")
ax1.set(xlabel = 'min_df', ylabel = 'mean squared error')
ax2.legend(loc = "upper right", title="max_df")
ax2.set(xlabel = 'min_df', ylabel = 'mean absolute error')

#Definitive feature matrix for analysis
reviews_df = pd.read_csv('clean_reviews.csv')
x=reviews_df['comments']
vectorizer = TfidfVectorizer(stop_words=nltk.corpus.stopwords.words('english'), min_df=0.1)
X = vectorizer.fit_transform(x.values.astype(str))
tfidf_df = pd.DataFrame(X.toarray(), columns=vectorizer.get_feature_names_out())
appended_df = pd.concat([reviews_df, tfidf_df], axis=1)
appended_df.drop(columns=['comments'], inplace=True)
appended_df = appended_df.groupby(appended_df['listing_id'], as_index=False).mean()
feature_df = pd.merge(listing_df,
                      appended_df.rename(columns={'listing_id':'id'}), on='id', how='left')
feature_df = feature_df.fillna(0)
feature_df = feature_df.replace('nan', 0)
feature_df['property_price'].replace(',', '', regex=True, inplace=True)
feature_df.to_csv('full_features.csv', index=False)

#Ridge, LASSO and dummy under different C, fixed min/max_df
colours = ['red', 'orange', 'gold', 'green', 'blue', 'indigo', 'violet']
X = feature_df.iloc[:, 8:].to_numpy()
fig, (ax1, ax2, ax3) = plt.subplots(1,3)
C_range = [0.001, 0.1, 1, 10, 100]
for i in range(1,8):
    y = feature_df.iloc[:, i]
    mean_MSE_L = []
    std_MSE_L = []
    mean_MSE_R = []
    std_MSE_R = []
    mean_MSE_D = []
    std_MSE_D = []
    for C in C_range:
        model_L = Lasso(alpha=1 / (2 * C))
        model_R = Ridge(alpha=1 / (2 * C))
        model_D = DummyRegressor(strategy='mean')
        temp_MSE_L = []
        temp_MSE_R = []
        temp_MSE_D = []
        for train, test in KFold(n_splits=5).split(X):
            model_L.fit(X[train], y[train])
            ypred = model_L.predict(X[test])
            temp_MSE_L.append(MSE(y[test], ypred))
            model_R.fit(X[train], y[train])
            ypred = model_R.predict(X[test])
            temp_MSE_R.append(MSE(y[test], ypred))
            model_D.fit(X[train], y[train])
            ypred = model_D.predict(X[test])
            temp_MSE_D.append(MSE(y[test], ypred))
        mean_MSE_L.append(np.array(temp_MSE_L).mean())
        std_MSE_L.append(np.array(temp_MSE_L).std())
        mean_MSE_R.append(np.array(temp_MSE_R).mean())
        std_MSE_R.append(np.array(temp_MSE_R).std())
        mean_MSE_D.append(np.array(temp_MSE_D).mean())
        std_MSE_D.append(np.array(temp_MSE_D).std())
    ax1.errorbar(C_range, mean_MSE_L, yerr=std_MSE_L, linewidth=2, color=colours[i-1])
    ax2.errorbar(C_range, mean_MSE_R, yerr=std_MSE_R, linewidth=2, color=colours[i-1])
    ax3.errorbar(C_range, mean_MSE_D, yerr=std_MSE_D, linewidth=2, color=colours[i - 1],
                 label=feature_df.columns[i].split('_')[2])
ax1.set(xlabel = 'C', ylabel = 'mean squared error', title = 'Lasso')
ax2.set(xlabel = 'C', ylabel = 'mean squared error', title = 'Ridge')
ax3.legend(loc = "upper right", title="review metric")
ax3.set(xlabel = 'C', ylabel = 'mean squared error', title = 'Dummy')

#MLP under different numbers of hidden layers
fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2,2)
C_range = [1, 50, 100, 200, 500]
for i in range(1,8):
    y = feature_df.iloc[:, i]
    mean_MSE_M5 = []
    std_MSE_M5 = []
    mean_MSE_M25 = []
    std_MSE_M25 = []
    mean_MSE_M50 = []
    std_MSE_M50 = []
    mean_MSE_M100 = []
    std_MSE_M100 = []
    for C in C_range:
        model_M5 = MLPRegressor(alpha=1 /C, hidden_layer_sizes=(5), max_iter=300)
        model_M25 = MLPRegressor(alpha=1 /C, hidden_layer_sizes=(25), max_iter=300)
        model_M50 = MLPRegressor(alpha=1 /C, hidden_layer_sizes=(50), max_iter=300)
        model_M100 = MLPRegressor(alpha=1 /C, hidden_layer_sizes=(100), max_iter=300)
        temp_MSE_M5 = []
        temp_MSE_M25 = []
        temp_MSE_M50 = []
        temp_MSE_M100 = []
        for train, test in KFold(n_splits=5).split(X):
            model_M5.fit(X[train], y[train])
            ypred = model_M5.predict(X[test])
            temp_MSE_M5.append(MSE(y[test], ypred))
            model_M25.fit(X[train], y[train])
            ypred = model_M25.predict(X[test])
            temp_MSE_M25.append(MSE(y[test], ypred))
            model_M50.fit(X[train], y[train])
            ypred = model_M50.predict(X[test])
            temp_MSE_M50.append(MSE(y[test], ypred))
            model_M100.fit(X[train], y[train])
            ypred = model_M100.predict(X[test])
            temp_MSE_M100.append(MSE(y[test], ypred))
        mean_MSE_M5.append(np.array(temp_MSE_M5).mean())
        std_MSE_M5.append(np.array(temp_MSE_M5).std())
        mean_MSE_M25.append(np.array(temp_MSE_M25).mean())
        std_MSE_M25.append(np.array(temp_MSE_M25).std())
        mean_MSE_M50.append(np.array(temp_MSE_M50).mean())
        std_MSE_M50.append(np.array(temp_MSE_M50).std())
        mean_MSE_M100.append(np.array(temp_MSE_M100).mean())
        std_MSE_M100.append(np.array(temp_MSE_M100).std())
    ax1.errorbar(C_range, mean_MSE_M5, yerr=std_MSE_M5, linewidth=2, color=colours[i - 1])
    ax2.errorbar(C_range, mean_MSE_M25, yerr=std_MSE_M25, linewidth=2, color=colours[i - 1])
    ax3.errorbar(C_range, mean_MSE_M50, yerr=std_MSE_M50, linewidth=2, color=colours[i - 1],
                 label=feature_df.columns[i].split('_')[2])
    ax4.errorbar(C_range, mean_MSE_M100, yerr=std_MSE_M100, linewidth=2, color=colours[i - 1])
ax3.legend(loc = "upper right", title="review metric")
ax1.set(xlabel = 'C', ylabel = 'mean squared error', title = 'MLP - 5 neurons', ylim = [0,500])
ax2.set(xlabel = 'C', title = 'MLP - 25 neurons', ylim = [0,500])
ax3.set(xlabel = 'C', ylabel = 'mean squared error', title = 'MLP - 50 neurons', ylim = [0,500])
ax4.set(xlabel = 'C', title = 'MLP - 100 neurons', ylim = [0,500])

#comparison table for preferred methods
model_LR = Ridge(alpha = 0.5)
model_MLP = MLPRegressor(hidden_layer_sizes=(5), alpha=1/200, max_iter=1000)
model_dummy = DummyRegressor(strategy='mean')
time_LR = 0
time_MLP = 0
time_dummy = 0
final_results_df = pd.DataFrame(columns=['review_metric', 'LR_MSE',
                                         'MLP_MSE', 'Dummy_MSE', 'LR_MAE', 'MLP_MAE', 'Dummy_MAE'])
for i in range(1,8):
    kf = KFold(n_splits=5)
    y = feature_df.iloc[:, i]
    temp_MSE_LR = []
    temp_MSE_MLP = []
    temp_MSE_dummy = []
    temp_MAE_LR = []
    temp_MAE_MLP = []
    temp_MAE_dummy = []
    #LR
    tic = time.time()
    for train, test in kf.split(X):
        model_LR.fit(X[train], y[train])
        if i==1:
            coeff_list_1 = sorted(list(zip(model_LR.coef_,
                                           feature_df.iloc[:, 8:].columns.tolist())),
                                  reverse=True, key=lambda x: x[0])
        ypred = model_LR.predict(X[test])
        temp_MSE_LR.append(MSE(y[test], ypred))
        temp_MAE_LR.append(MAE(y[test], ypred))
    mean_MSE_LR = np.array(temp_MSE_LR).mean()
    mean_MAE_LR = np.array(temp_MAE_LR).mean()
    time_LR += time.time() - tic
    #MLP
    tic = time.time()
    for train, test in kf.split(X):
        model_MLP.fit(X[train], y[train])
        ypred = model_MLP.predict(X[test])
        temp_MSE_MLP.append(MSE(y[test], ypred))
        temp_MAE_MLP.append(MAE(y[test], ypred))
    mean_MSE_MLP = np.array(temp_MSE_MLP).mean()
    mean_MAE_MLP = np.array(temp_MAE_MLP).mean()
    time_MLP += time.time() - tic
    #dummy
    tic = time.time()
    for train, test in kf.split(X):
        model_dummy.fit(X[train], y[train])
        ypred = model_dummy.predict(X[test])
        temp_MSE_dummy.append(MSE(y[test], ypred))
        temp_MAE_dummy.append(MAE(y[test], ypred))
    mean_MSE_dummy = np.array(temp_MSE_dummy).mean()
    mean_MAE_dummy = np.array(temp_MAE_dummy).mean()
    time_MLP += time.time() - tic
    new_row = {'review_metric': feature_df.columns[i].split('_')[2],
               'LR_MSE': mean_MSE_LR, 'MLP_MSE': mean_MSE_MLP, 'Dummy_MSE': mean_MSE_dummy,
               'LR_MAE': mean_MAE_LR, 'MLP_MAE': mean_MAE_MLP, 'Dummy_MAE': mean_MAE_dummy}
    final_results_df = final_results_df.append(new_row, ignore_index=True)
final_results_df.loc[7] = final_results_df.sum()
final_results_df.at[7, 'review_metric'] = 'total'
with pd.option_context('display.max_rows', None, 'display.max_columns', None):
    print(final_results_df)
print('Execution times:')
print('LR: ' + str(time_LR) + ' seconds')
print('MLP: ' + str(time_MLP) + ' seconds')
print('Dummy: ' + str(time_dummy) + ' seconds')

coeff_list_7 = sorted(list(zip(model_LR.coef_,
                               feature_df.iloc[:, 8:].columns.tolist())),
                      reverse=True, key=lambda x: x[0])
print('\n First Metric:')
print(*coeff_list_1, sep='\n')
print('\n Last Metric:')
print(*coeff_list_7, sep='\n')

plt.show()